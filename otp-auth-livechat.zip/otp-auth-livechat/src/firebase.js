// src/firebase.js
import { initializeApp } from 'firebase/app'
import {
  getAuth,
  sendSignInLinkToEmail,
  isSignInWithEmailLink,
  signInWithEmailLink,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  signOut as firebaseSignOut
} from 'firebase/auth'
import { getFirestore, collection, addDoc, serverTimestamp, query, orderBy, onSnapshot } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)

// Email link helpers
export async function sendEmailLink(email) {
  const actionCodeSettings = {
    // This URL should be registered in Firebase Console -> Auth -> Authorized domains
    url: window.location.href,
    handleCodeInApp: true
  }
  return sendSignInLinkToEmail(auth, email, actionCodeSettings)
}

export function tryEmailLinkSignIn() {
  if (isSignInWithEmailLink(auth, window.location.href)) {
    // get email from localStorage or ask user to re-enter
    let email = window.localStorage.getItem('emailForSignIn')
    if (!email) {
      email = window.prompt('Please provide your email for confirmation')
    }
    if (email) return signInWithEmailLink(auth, email, window.location.href)
  }
  return Promise.reject(new Error('No email link sign-in to process'))
}

// Phone helpers
export function setupRecaptcha(containerId = 'recaptcha-container') {
  // Only create once
  if (window.recaptchaVerifier) return window.recaptchaVerifier
  const recaptcha = new RecaptchaVerifier(containerId, { size: 'invisible' }, auth)
  window.recaptchaVerifier = recaptcha
  return recaptcha
}

export function sendSmsOtp(phoneNumber) {
  setupRecaptcha()
  return signInWithPhoneNumber(auth, phoneNumber, window.recaptchaVerifier)
}

export function signOut() {
  return firebaseSignOut(auth)
}

export { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot }
