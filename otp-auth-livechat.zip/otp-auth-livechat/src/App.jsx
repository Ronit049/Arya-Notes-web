// src/App.jsx
import React, { useEffect, useState, useRef } from 'react'
import { auth, db, sendEmailLink, tryEmailLinkSignIn, sendSmsOtp, signOut as doSignOut, collection, addDoc, serverTimestamp, query, orderBy, onSnapshot } from './firebase'
import { onAuthStateChanged } from 'firebase/auth'

export default function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [confirmationResult, setConfirmationResult] = useState(null)
  const [smsCode, setSmsCode] = useState('')

  // chat
  const [message, setMessage] = useState('')
  const [messages, setMessages] = useState([])
  const messagesRef = useRef(null)

  useEffect(() => {
    onAuthStateChanged(auth, (u) => {
      setUser(u)
      setLoading(false)
    })

    // If the URL contains email sign-in link, try signing in automatically
    if (window.location.href.includes('mode=signIn') || window.location.href.includes('oobCode')) {
      tryEmailLinkSignIn().catch(() => {})
    }
  }, [])

  // load messages when logged in
  useEffect(() => {
    let unsub
    if (user) {
      const q = query(collection(db, 'messages'), orderBy('createdAt'))
      unsub = onSnapshot(q, (snap) => {
        const arr = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
        setMessages(arr)
        // scroll
        setTimeout(() => messagesRef.current?.scrollIntoView({ behavior: 'smooth' }), 50)
      })
    }
    return () => unsub && unsub()
  }, [user])

  async function handleSendEmailLink(e) {
    e.preventDefault()
    try {
      await sendEmailLink(email)
      window.localStorage.setItem('emailForSignIn', email)
      alert('Email link sent. Check your inbox and click the link to sign in.')
    } catch (err) {
      alert('Failed to send email link: ' + err.message)
    }
  }

  async function handleSendSms(e) {
    e.preventDefault()
    try {
      // phone must include country code, e.g. +9198xxxxxxx
      const cr = await sendSmsOtp(phone)
      setConfirmationResult(cr)
      alert('OTP sent to phone. Enter code and confirm.')
    } catch (err) {
      alert('Failed to send SMS: ' + err.message)
    }
  }

  async function confirmSms() {
    if (!confirmationResult) return alert('No OTP requested')
    try {
      await confirmationResult.confirm(smsCode)
      setSmsCode('')
      setConfirmationResult(null)
    } catch (err) {
      alert('Invalid code: ' + err.message)
    }
  }

  async function handleSignOut() {
    await doSignOut()
  }

  async function postMessage(e) {
    e.preventDefault()
    if (!message.trim()) return
    if (!user) return alert('Sign in first')
    await addDoc(collection(db, 'messages'), {
      text: message.trim(),
      uid: user.uid,
      displayName: user.displayName || user.email || user.phoneNumber || 'Anonymous',
      createdAt: serverTimestamp()
    })
    setMessage('')
  }

  if (loading) return <div className="p-6">Loading...</div>

  return (
    <div className="min-h-screen p-6 font-sans">
      <style>{`body{font-family: Arial, Helvetica, sans-serif}`}</style>
      <h1>OTP Auth Live Chat (Demo)</h1>

      {!user ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          <section>
            <h2>Email (magic link / OTP-like)</h2>
            <form onSubmit={handleSendEmailLink}>
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
              <button type="submit">Send email sign-in link</button>
            </form>
            <p>After clicking the link, you'll be signed in. We store the email in localStorage temporarily.</p>
          </section>

          <section>
            <h2>Phone (SMS OTP)</h2>
            <div id="recaptcha-container"></div>
            <form onSubmit={handleSendSms}>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+9198xxxxxxx" />
              <button type="submit">Send SMS OTP</button>
            </form>

            {confirmationResult && (
              <div>
                <input value={smsCode} onChange={(e) => setSmsCode(e.target.value)} placeholder="Enter SMS code" />
                <button onClick={confirmSms}>Confirm code</button>
              </div>
            )}

            <p>
              Note: Phone auth requires that your app domain (localhost for dev) is authorized in Firebase console and reCAPTCHA is allowed.
            </p>
          </section>
        </div>
      ) : (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              Signed in as <b>{user.email || user.phoneNumber || user.uid}</b>
            </div>
            <div>
              <button onClick={handleSignOut}>Sign out</button>
            </div>
          </div>

          <main style={{ marginTop: 20 }}>
            <div style={{ border: '1px solid #ddd', padding: 10, height: 400, overflow: 'auto' }}>
              {messages.map((m) => (
                <div key={m.id} style={{ padding: 6, borderBottom: '1px solid #eee' }}>
                  <div style={{ fontSize: 12, color: '#555' }}>{m.displayName}</div>
                  <div>{m.text}</div>
                </div>
              ))}
              <div ref={messagesRef} />
            </div>

            <form onSubmit={postMessage} style={{ marginTop: 10 }}>
              <input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Type a message" style={{ width: '80%' }} />
              <button type="submit">Send</button>
            </form>
          </main>
        </div>
      )}

      <div style={{ marginTop: 30 }}>
        <h3>Developer notes</h3>
        <ol>
          <li>Before using phone auth, call <code>setupRecaptcha()</code> or include a visible reCAPTCHA container.</li>
          <li>Enable Email Link sign-in and Phone providers in Firebase Console.</li>
          <li>Add your dev domain (http://localhost:5173 or where you run vite) to Authorized domains in Firebase Auth settings.</li>
        </ol>
      </div>
    </div>
  )
}
