# OTP Auth LiveChat (React + Firebase)

## Setup
1. Create a Firebase project at https://console.firebase.google.com
2. Enable Authentication -> Sign-in method: Email Link (passwordless) and Phone
3. Add your local dev domain (e.g. http://localhost:5173) to Authorized domains
4. Create Firestore database in test mode for quick start
5. Copy values to `.env` (based on `.env.example`)

## Dev

```bash
npm install
npm run dev
```

Open http://localhost:5173

Notes: Phone auth requires reCAPTCHA - the demo uses the invisible reCAPTCHA. For production, read Firebase docs about safety & quotas.
